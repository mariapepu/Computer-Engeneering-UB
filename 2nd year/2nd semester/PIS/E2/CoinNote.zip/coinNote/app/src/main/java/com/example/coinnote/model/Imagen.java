package com.example.coinnote.model;

public class Imagen {
    private String path;

    public Imagen(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
