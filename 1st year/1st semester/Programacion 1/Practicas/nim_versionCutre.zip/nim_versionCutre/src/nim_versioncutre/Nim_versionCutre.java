/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nim_versioncutre;

import java.util.Scanner;

/**
 *
 * @author Maria
 */
public class Nim_versionCutre {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int fitxes_orde, nombre_fitxes;
        //decidimos cuantas fichas hay al inicio
        nombre_fitxes = (int) Math.floor (Math.random()*(30-20)+20);
        System.out.println("Al tauler hi ha "+nombre_fitxes+" fitxes.");
        //en caso que iniciPartida sea 1, empieza el orde, si es 2 empieza el jugador.
        //en caso que empieze el orednador haremos la primer tirada fuera del bucle
        if (iniciPartida()){
            System.out.println("Comença l'Ordinador");
            fitxes_orde=treureFitxesAleatori();
            System.out.println("L'ordinador treu "+fitxes_orde+" fitxes");
            nombre_fitxes -= fitxes_orde;
            System.out.println("Queden "+nombre_fitxes+" fitxes.");
        }else
            System.out.println("Comença el Jugador");
        
        //empieza la partida en sí.
        while (nombre_fitxes > 0){
            nombre_fitxes -= treureFitxes();
            System.out.println("Queden "+nombre_fitxes+" fitxes.");
            if (nombre_fitxes==0){
                System.out.println("has guanyat");
            }
            else{
            fitxes_orde = treureFitxesAleatori();      
            System.out.println("L'ordinador treu "+fitxes_orde+" fitxes");
            nombre_fitxes -= fitxes_orde;
            System.out.println("Queden "+nombre_fitxes+" fitxes.");
                if (nombre_fitxes==0){
                    System.out.println("L'ordinador ha guanyat");
                }
            }            
        }
    }
    
    //metodo para quitar fichas
    public static int treureFitxes(){
        int fitxes;
        System.out.println("Quantes fitxes vols treure? (1 o 2)");
        Scanner entrada = new Scanner (System.in);
        fitxes = entrada.nextInt();
        return fitxes;
    }
    
    //metodo para quitar fichas de forma random
    public static int treureFitxesAleatori(){
         int fitxes = (int) (Math.random() * (2-1+1) + 1);
         return fitxes;
    }
    
    //metodo para decidir quien empieza
    public static boolean iniciPartida(){
        int comensa = (int) (Math.random() * (2-1+1) + 1);
        return comensa==1;
    }
}
