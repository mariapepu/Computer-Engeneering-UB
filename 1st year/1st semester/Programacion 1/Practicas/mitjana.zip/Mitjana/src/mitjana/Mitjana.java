/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mitjana;

import java.util.Scanner;

/**
 *
 * @author Maria
 */
public class Mitjana {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int sum = 0, a = 0;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Quants nombres vols introduir?");
        int n = entrada.nextInt();
        System.out.println("La mitjana del nombres parells introduits es: " + mitjana(sum ,a,n));
    }
    
    public static int mitjana(int sum, int a, int n){
        Scanner entrada = new Scanner(System.in);
        System.out.println("Introdueix " + n + " nombres");
        int num;
        while (n > 0) {
            num = entrada.nextInt();
            if (num % 2 == 0) {
                sum += num;
                a++;
            }
            n--;
        }
        
        return sum / a;
    } 

}
