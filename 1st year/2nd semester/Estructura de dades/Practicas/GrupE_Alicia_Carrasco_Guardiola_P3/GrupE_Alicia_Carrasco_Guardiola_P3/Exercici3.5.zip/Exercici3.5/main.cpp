/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: user
 *
 * Created on 24 de mayo de 2020, 11:06
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout << endl << "Alicia Carrasco" << endl << endl;
    
    cout << " ------------------------------------------------------------------- " << endl; 
    cout << "|         |  Inserció    |  Inserció   |    Cerca     |    Cerca    |" << endl;
    cout << "|         | Fitxer Short | Fitxer Long | Fitxer Short | Fitxer Long |" << endl; 
    cout << "|-------------------------------------------------------------------|" << endl; 
    cout << "|         |              |             |              |             |" << endl; 
    cout << "| BSTree  |      0       |      2      |      0       |      2      |" << endl; 
    cout << "|         |              |             |              |             |" << endl; 
    cout << "|-------------------------------------------------------------------|" << endl; 
    cout << "|         |              |             |              |             |" << endl; 
    cout << "| AVLTree |      0       |      9      |      0       |      ?      |" << endl; 
    cout << "|         |              |             |              |             |" << endl; 
    cout << " ------------------------------------------------------------------- " << endl; 
    
    cout << endl << endl << "La inserció del Fitxer Short serà molt semblant ja "
            "que és un fitxer amb poques paraules." << endl;
    cout << "La inserció del Fitxer Long és superior en el AVLTree ja que ha d'anar "
            "mirant si s'ha de balancejar l'arbre i, en cas que sigui necessari,"
            << endl << "fer-ho. En el BSTree en canvi només haurà d'insertar la "
            "paraula." << endl;
    cout << "La cerca en el Fitxer Short novament serà semblant ja que, al ser"
            "poques paraules, serà ràpid cercar." << endl;
    cout << "Serà a l'hora de cercar en el fitxer llarg quan ens adonarem que és "
            "molt més ràpid l'AVL ja que, al estar balancejat, haurà de passar "
            "per" << endl << "menys posicions." << endl;
    cout << "En el meu cas no he pogut comprovar el temps de cerca, ja que no se "
            "m'afegien bé les paraules, tot i que en l'exercici 3 pensava haver"
            << endl << "considerat tots els cassos." << endl;
    
    cout << "En el main dels exercicis 1 i 3 es poden observar les complexitats "
            "dels mètodes, mostrant que la majoria de mètodes de l'AVL "
            "tenen un cost" << endl << "computacional menor." << endl;
    
    return 0;
}