/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: user
 *
 * Created on 19 de abril de 2020, 16:29
 */

#include <cstdlib>
#include <iostream>

#include "BSTree.h"
#include "Position.h"
#include "AVLTree.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    /* 1. Crear dos arbres (anomenats primer i segon) que emmagatzemin la clau
     * entera i valors enters. */
    AVLTree<int, int>* primer = new AVLTree<int, int>(); 
    cout << endl;
    /* 2. Inserir a l'arbre (primer) les claus d'un array anomenat testArray que
     * contindrà: int testArray [] = {2, 0, 8, 45, 76, 5, 3, 40};
     * Com a valor inserteu el mateix que la clau. */
    int testArray [] = {2, 0, 8, 45, 76, 5, 3, 36, 35, 40, 1, 7, 90, 46, 26, 34, 96};
    for (int i = 0; i < (sizeof(testArray) / sizeof(int)); i++) {
        primer->insert(testArray[i], testArray[i]);
        primer->printPreOrder();
    }
    cout << endl;
    /* 3. Mostrar en preordre l’arbre (primer) per pantalla
     * Preordre = {2, 0, 8, 5, 3, 45, 40, 76} */
    primer->printPreOrder();
    cout << endl;
    /* 4. Mostrar en postordre l’arbre (primer) per pantalla
     * Postordre = { 0, 3, 5, 40, 76, 45, 8, 2} */
    primer->printPostOrder();
    cout << endl;    
    /* 5. Fer una còpia de l’arbre primer sobre el segon arbre binari copiat */
    BSTree<int, int> segon(*primer);
    cout << endl;
    /* 6. Cridar a la funció primer.identicalTree(segon) Cert */
    // NO DONA EL RESULTAT ESPERAT :(
    if (primer->identicalTree(segon)) cout << "Cert!!" << endl;
    else cout << "Fals!!" << endl;
    cout << endl;
    /* 7. Afegir a l’arbre primer l’element amb clau 1
     * Inserta a l’arbre l’element 1 */
    primer->insert(1, 1);
    cout << endl;
    /* 8. Cridar a la funció segon.identicalTree(primer) Fals */
    if (segon.identicalTree(*primer)) cout << "Cert!!" << endl;
    else cout << "Fals!!" << endl;
    cout << endl;
    /* 9 Eliminar l'arbre */
    primer->~BSTree();
    return 0;
}

/*
 * La complexitat dels mètodes position seran les mateixes, ja que no he
 * canviat res. Només canviaran aquelles noves implementades al AVLTree i les
 * del BSTree degut a la nova distribució de l'arbre.
 * 
 * AVLTree() ----------------------------------------------------------> O(1)
 * AVLTree(const AVLTree<K, V>& orig) ---------------------------------> O(n)
 * virtual ~AVLTree() -------------------------------------------------> O(n)
 * Position<K, V>* insert(const K& key, const Tuple<V>& value) ----> O(log n)
 * Position<K, V>* insert_recursiu(&key, &value, *pos, &size) const> O(log n)
 * Position<K,V>* getAlfa(Position<K,V>* pos) ---------------------> O(log n)
 * int factorBalance(Position<K, V>* pos) -------------------------> O(log n)
 * Position<K, V>* rotacio_simple_esquerra(Position<K, V>* pos) -------> O(1)
 * Position<K, V>* rotacio_simple_dreta(Position<K, V>* pos) ----------> O(1)
 * Position<K, V>* rotacio_dreta_esquerra(Position<K, V>* pos) --------> O(1)
 * Position<K, V>* rotacio_esquerra_dreta(Position<K, V>* pos) --------> O(1)
 * 
 * isEmpty() const ----------------------------------------------------> O(1)
 * getRoot() const ----------------------------------------------------> O(1)
 * size() const -------------------------------------------------------> O(n)
 * height() const -------------------------------------------------> O(log n)
 * contains(const K& key) const -----------------------------------> O(log n)
 * vector<V>& getValues(const K& key) const ---------------------------> O(n)
 * printPreOrder(const Position<K, V> *node) const --------------------> O(n)
 * printPostOrder(const Position<K, V> *node) const -------------------> O(n)
 * identicalTree(const BSTree<K, V>& other) const ---------------------> O(n)
 * _search(const K& key) const ------------------------------------> O(log n)
 * _search_recursiu(&key, *pos) const -----------------------------> O(log n)
 * size_recursiu(Position<K, V>* pos) const ---------------------------> O(n)
 * insert_recursiu(&key, &value, *pos, &size) const ---------------> O(log n)
 * identicalTree_rec(&other, *other_pos, *pos) const ------------------> O(n)
 * void printPreOrder_recursiu(*node) const ---------------------------> O(n)
 * void printPostOrder_recursiu(*node) const --------------------------> O(n)
 */