/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AVLTree.h
 * Author: user
 *
 * Created on 9 de mayo de 2020, 10:29
 */

#ifndef AVLTREE_H
#define AVLTREE_H

#include "Position.h"
#include "BSTree.h"

using namespace std;

template <class K, class V>
class AVLTree : public BSTree<K, V>{
public:
    AVLTree();
    AVLTree(const AVLTree<K, V>& orig);
    virtual ~AVLTree();
    
    Position<K, V>* insert(const K& key, const Tuple<V>& value);
    
private:
    Position<K, V>* insert_recursiu(const K& key, const Tuple<V>& value, Position<K,V>* pos, int &size) const;
    Position<K,V>* getAlfa(Position<K,V>* pos);
    int factorBalance(Position<K, V>* pos);
    Position<K, V>* rotacio_simple_esquerra(Position<K, V>* pos);
    Position<K, V>* rotacio_simple_dreta(Position<K, V>* pos);
    Position<K, V>* rotacio_dreta_esquerra(Position<K, V>* pos);
    Position<K, V>* rotacio_esquerra_dreta(Position<K, V>* pos);
};

template <class K, class V>
AVLTree<K, V>::AVLTree() {
    
}

template <class K, class V>
AVLTree<K, V>::AVLTree(const AVLTree<K, V>& orig) {
    
}

template <class K, class V>
AVLTree<K, V>::~AVLTree() {
    
}

template <class K, class V>
Position<K, V>* AVLTree<K, V>::insert(const K& key, const Tuple<V>& value) {
    // Cas primer element
    if (this->isEmpty()) {
        this->root = new Position<K, V>(key);
        this->root->addValue(value);
        this->_size++;
        cout << "S'ha insertat " << key << " com a root!" << endl;
        return this->root;
    } else {
        // Insertem element
        Position<K, V>* position = insert_recursiu(key, value, this->root, this->_size);
        Position<K, V>* alfa = getAlfa(position);
        // Si hi ha alfa, està desbalancejat i s'ha de balancejar
        if (alfa) {
            // SIMPLE ESQUERRA
            // serà la de quan s'inserta el 75
            if (alfa->getKey() < position->getKey() and alfa->right()->getKey() < position->getKey()) {
                rotacio_simple_esquerra(alfa);
            }
            // SIMPLE DRETA
            else if (alfa->getKey() > position->getKey() and alfa->left()->getKey() > position->getKey()) {
                rotacio_simple_dreta(alfa);
            }
            // DOBLE DRETA-ESQUERRA
            else if (alfa->getKey() < position->getKey() and alfa->right()->getKey() > position->getKey()) {
                //rotacio_dreta_esquerra(alfa);
            }
            // DOBLE ESQUERRA-DRETA
            else if (alfa->getKey() > position->getKey() and alfa->left()->getKey() < position->getKey()) {
                //rotacio_esquerra_dreta(alfa);
            }
        }
        return position;
    }
}

template <class K, class V>
Position<K, V>* AVLTree<K, V>::insert_recursiu(const K& key, const Tuple<V>& value, Position<K,V>* pos, int &size) const {
    // Si existeix, se li afegeix el nou valor
    if (key == pos->getKey()) {
        pos->addValue(value);
        cout << "La clau ja existia. S'ha afegit el valor a " <<
                key << "! :)" << endl;
        return pos;
    }
    // Si no existeix i hauria de situar-se cap a l'esquerra
    else if (key < pos->getKey()) {
        if (pos->left()) return insert_recursiu(key, value, pos->left(), size);
        else {
            Position<K, V>* position = new Position<K, V>(key);
            position->addValue(value);
            position->setParent(pos);
            position->parent()->setLeft(position);
            size++;
            cout << "S'ha insertat " << key << "!" << endl;
            return position;
        }
    } 
    // Si no existeix i hauria de situar-se cap a la dreta
    else if (key > pos->getKey()) {
        if (pos->right()) return insert_recursiu(key, value, pos->right(), size);
        else {
            Position<K, V>* position = new Position<K, V>(key);
            position->addValue(value);
            position->setParent(pos);
            position->parent()->setRight(position);
            size++;
            cout << "S'ha insertat " << key << "!" << endl;
            return position;
        }
    }
}

template <class K, class V>
Position<K,V>* AVLTree<K, V>::getAlfa(Position<K,V>* pos) {
    while (pos) {
        int fb = factorBalance(pos);
        if (fb > 1 or fb < -1) return pos;
        else if (pos->parent()) pos = pos->parent();
        else return nullptr;
    }
}

template <class K, class V>
int AVLTree<K, V>::factorBalance(Position<K, V>* pos) {
    int esquerra, dreta;
    if (pos->left()) esquerra = pos->left()->height();
    else esquerra = 0;
    if (pos->right()) dreta = pos->right()->height();
    else dreta = 0;
    return dreta - esquerra;
}

template <class K, class V>
Position<K, V>* AVLTree<K, V>::rotacio_simple_esquerra(Position<K,V>* pos) {
    // Si té fills
    bool fills = false;
    Position<K, V>* aux;
    if(pos->right()->left()) {
        aux = pos->right()->left();
        fills = true;
    }
    if (pos->isRoot()) {
        pos->right()->setParent(nullptr);
        this->root = pos->right();
    }
    else {
        pos->right()->setParent(pos->parent());
        if (pos->right()->getKey() < pos->parent()->getKey()) pos->parent()->setLeft(pos->right());
        else if (pos->right()->getKey() > pos->parent()->getKey()) pos->parent()->setRight(pos->right());
    }
    pos->setParent(pos->right());
    pos->right()->setLeft(pos);
    if (fills) pos->setRight(aux);
    else pos->setRight(nullptr);
    pos->setLeft(nullptr);
    return pos;
}

template <class K, class V>
Position<K, V>* AVLTree<K, V>::rotacio_simple_dreta(Position<K, V>* pos) {
    // Si té fills
    bool fills = false;
    Position<K, V>* aux;
    if (pos->left()->right()) {
        aux = pos->left()->right();
        fills = true;
    }
    if (pos->isRoot()) {
        pos->left()->setParent(nullptr);
        this->root = pos->left();
    }
    else {
        pos->left()->setParent(pos->parent());
        if (pos->left()->getKey() < pos->parent()->getKey()) pos->parent()->setLeft(pos->left());
        else pos->parent()->setRight(pos->left());
    }
    pos->setParent(pos->left());
    pos->left()->setRight(pos);
    if (fills) pos->setLeft(aux);
    else pos->setLeft(nullptr);
    pos->setRight(nullptr);
    return pos;
}

template <class K, class V>
Position<K, V>* AVLTree<K, V>::rotacio_esquerra_dreta(Position<K, V>* pos) {
    pos->setLeft(pos->left()->right());
    pos->left()->setLeft(pos->left()->parent());
    pos->left()->parent()->setParent(pos->left());
    pos->left()->setParent(pos);
    pos->left()->left()->setRight(nullptr);
    return rotacio_simple_dreta(pos);
}

template <class K, class V>
Position<K, V>* AVLTree<K, V>::rotacio_dreta_esquerra(Position<K, V>* pos) {
    pos->setRight(pos->right()->left());
    pos->right()->setRight(pos->right()->parent());
    pos->right()->parent()->setParent(pos->right());
    pos->right()->setParent(pos);
    pos->right()->right()->setLeft(nullptr);
    return rotacio_simple_esquerra(pos);
}

#endif /* AVLTREE_H */

