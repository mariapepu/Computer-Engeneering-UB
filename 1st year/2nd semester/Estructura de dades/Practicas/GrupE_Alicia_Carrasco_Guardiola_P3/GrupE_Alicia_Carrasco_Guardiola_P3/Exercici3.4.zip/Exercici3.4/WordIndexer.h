/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   WordIndexer.h
 * Author: user
 *
 * Created on 1 de mayo de 2020, 20:52
 */

#ifndef WORDINDEXER_H
#define WORDINDEXER_H

#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <stdio.h>
#include "Tuple.h"
#include "AVLTree.h"
#include "Position.h"

using namespace std;

template <class K, class V>
class WordIndexer {
public:
    WordIndexer();
    WordIndexer(const WordIndexer& orig);
    virtual ~WordIndexer();
    bool contains(const K& word);
    void printDictionary();
    void addText(string filename);
    Position<K, V>* insertWord(K word, V line, V positionWord);
    int profunditat() const;
    void paraulaIndex();
private:
    AVLTree<K, V>* tree;
    K word;
    void paraulaIndex_recursiu(Position<K, V>* pos);
};

template <class K, class V>
WordIndexer<K, V>::WordIndexer() {
    this->tree = new AVLTree<K, V>();
}

template <class K, class V>
WordIndexer<K, V>::WordIndexer(const WordIndexer& orig) {
    
}

template <class K, class V>
WordIndexer<K, V>::~WordIndexer() {
    delete(tree);
}

template <class K, class V>
bool WordIndexer<K, V>::contains(const K& word) {
    tree->contains(word);
}

template <class K, class V>
void WordIndexer<K, V>::printDictionary() {
    if (tree->isEmpty()) throw runtime_error("Arbre buit");
    tree->printInOrder40();    
}

template <class K, class V>
void WordIndexer<K, V>::addText(string filename) {
    ifstream arxiu(filename);
    string aux, paraula;
    int linia = 1, posicio = 1;
    if(arxiu.fail()) cout << "Error al obrir l'arxiu" << endl;
    while(!arxiu.eof()){
        arxiu >> paraula;
        string par_sense_signes = "";
        for (int i = 0; i < paraula.length(); i++) {
            if (paraula[i] != '.' and paraula[i] != ',' and paraula[i] != ':'
                and paraula[i] != ';' and paraula[i] != '!' and paraula[i]!= '?'
                and paraula[i] != '-' and paraula[i] != '_' and paraula[i] != '('
                and paraula[i] != ')') {
                par_sense_signes += tolower(paraula[i]);
            }
        } 
        insertWord(par_sense_signes, linia, posicio);
        posicio++;
    }
    arxiu.close();
}

template <class K, class V>
Position<K, V>* WordIndexer<K, V>::insertWord(K word, V line, V positionWord) {
    Tuple<V>* tupla = new Tuple<V>(line, positionWord);
    this->tree->insert(word, *tupla);
}

template <class K, class V>
int WordIndexer<K, V>::profunditat() const {
    return tree->height() - 1;
}

template <class K, class V>
void WordIndexer<K, V>::paraulaIndex() {
    Position<K, V>* pos = tree->getRoot();
    paraulaIndex_recursiu(pos);
}

template <class K, class V>
void WordIndexer<K, V>::paraulaIndex_recursiu(Position<K, V>* pos) {
    if (pos->left() != nullptr) paraulaIndex_recursiu(pos->left());
    cout << pos->getKey() << " [";
    for (int i = 0; i < pos->getValues().size(); i++) {
        cout << "(" << pos->getValues()[i].getLinia() << ", " << pos->getValues()[i].getPosicio() << ")";
    }
    cout << "] " << endl;
    if (pos->right() != nullptr) paraulaIndex_recursiu(pos->right());
}

#endif /* WORDINDEXER_H */