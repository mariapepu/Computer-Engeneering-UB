/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: user
 *
 * Created on 1 de mayo de 2020, 20:49
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <ctime>
#include "BSTree.h"
#include "Position.h"
#include "Tuple.h"
#include "WordIndexer.h"

using namespace std;

int menu(int &op){
    vector<string> menu = {"Sortir", "Llegir fitxer", "Imprimir arbre endreçat",
                           "Llegir diccionari", "Índex paraules",
                           "Profunditat arbre"};
    int num = 0;
    cout<< "\n\nTria una opció" <<endl;
        
        for (string opcio: menu) {
            cout << (num+1) << ". " << opcio << endl;
            num++;
        }
       num = 0;
    cin >> op;
    op--;
    if (cin.fail()) {
        cout << "Opció equivocada" << endl;
        cin.clear();
        cin.ignore(10000, '\n');
    }
    return op;
}

/*
 * 
 */
int main(int argc, char** argv) {
    WordIndexer<string, int>* wordInd = new WordIndexer<string, int>();
    int op = 1;
    clock_t start_t, end_t, total_t;
    while (op != 0) {
    op = menu(op);
    switch (op) {
        case 0:
        cout << "Sortint..." << endl;
        break;
        case 1:
        {
            char opcio;
            cout << "Quin fitxer vols? (P/G)" << endl;
            cin >> opcio;
            if (opcio == 'P' || opcio == 'p') {
                start_t = clock();
                wordInd->addText("shortText");
                end_t = clock(); 
                total_t = (double)(end_t - start_t) / CLOCKS_PER_SEC;
                cout << "Temps total: " << total_t << endl;
            } else if (opcio == 'G' || opcio == 'g') {
                start_t = clock();
                wordInd->addText("longText");
                end_t = clock(); 
                total_t = (double)(end_t - start_t) / CLOCKS_PER_SEC;
                cout << "Temps total: " << total_t << endl;
            }
        }
            break;
        case 2:
        {          
            wordInd->printDictionary();
        }
            break;
        case 3:
        {
            ifstream arxiu("dictionary");
            string paraula;
            int count = 0;
            start_t = clock();            
            while(!arxiu.eof()){
                arxiu >> paraula;
                if(wordInd->contains(paraula)) {
                    cout << paraula << endl;
                    count++;
                }
            }
            end_t = clock(); 
            total_t = (double)(end_t - start_t) / CLOCKS_PER_SEC;
            cout << endl << "Temps total: " << total_t << endl;
            arxiu.close();
            cout << endl << "En total hi ha " << count << " paraules" << endl;
        }
            break;
        case 4:
            wordInd->paraulaIndex();
            break;
        case 5:
        {
            cout <<  "La profunditat és " << wordInd->profunditat() << endl;
        }
            break;
        default:
            cout << "Ups!! No existeix :(" << endl;
        }
    }
    
    return 0;
}

