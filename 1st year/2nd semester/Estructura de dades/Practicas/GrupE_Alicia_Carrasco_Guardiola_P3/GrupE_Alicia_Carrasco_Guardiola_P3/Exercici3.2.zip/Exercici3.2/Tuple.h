/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tuple.h
 * Author: user
 *
 * Created on 1 de mayo de 2020, 20:51
 */

#ifndef TUPLE_H
#define TUPLE_H

#include <iostream>

template <class V>
class Tuple {
public:
    Tuple(V linia, V posicio);
    Tuple(const Tuple<V>& orig);
    virtual ~Tuple();
    const V getLinia() const;
    void setLinia(V linia);
    const V getPosicio() const;
    void setPosicio(V posicio);
    bool operator==(const Tuple<V>& other) const;
    bool operator<(const Tuple<V>& other) const;
    
private:
    V linia;
    V posicio;
};

template <class V>
Tuple<V>::Tuple(V linia, V posicio) {
    this->linia = linia;
    this->posicio = posicio;
}

template <class V>
Tuple<V>::Tuple(const Tuple<V>& orig) {
    this->linia = orig.linia;
    this->posicio = orig.posicio;
}

template <class V>
Tuple<V>::~Tuple() {
    
}

template <class V>
const V Tuple<V>::getLinia() const {
    return this->linia;
}

template <class V>
void Tuple<V>::setLinia(V linia) {
    this->linia = linia;
}

template <class V>
const V Tuple<V>::getPosicio() const {
    return this->posicio;
}

template <class V>
void Tuple<V>::setPosicio(V posicio) {
    this->posicio = posicio;
}

template <class V>
bool Tuple<V>::operator==(const Tuple<V>& other) const {
    return (linia == other.linia) and (posicio == other.posicio);
}

template <class V>
bool Tuple<V>::operator<(const Tuple<V>& other) const {
    return (linia < other.linia);
}

#endif /* TUPLE_H */

